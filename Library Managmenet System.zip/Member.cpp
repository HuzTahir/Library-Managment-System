#include "Member.h"
#include "Book.h" // Include the header file for the Book class

#include "Student.h"
#include "Faculty.h"
const int MAX_ISSUED_BOOKS=5;

Member::Member(void) 
{
}

Member::Member(string memberID, string name, string address, string phone, string type, int booksIssued) 
{
    this->memberID = memberID;
    this->name = name;
    this->address = address;
    this->phone = phone;
    this->type = type;
    this->booksIssued = booksIssued;
   // this->   card=new Card();
}

void Member::inputDetails() {
    std::cout << "Enter member ID: ";
    std::cin >> memberID;
    std::cout << "Enter member name: ";
    std::cin >> name;
    std::cout << "Enter member address: ";
    std::cin >> address;
    std::cout << "Enter member phone number: ";
    std::cin >> phone;
    std::cout << "Enter member type (1 for student, 2 for faculty): ";
    int typeInput;
    
    if (typeInput==1)
    	type="student";
    else
		type="faculty";	
    	
    std::cout << "Enter number of books issued: ";
    std::cin >> booksIssued;
}



string Member::getMemberID() {
    return memberID;
}

string Member::getName() {
    return name;
}

string Member::getAddress() {
    return address;
}

string Member::getPhone() {
    return phone;
}

string Member::getType() {
    return type;
}

int Member::getBooksIssued() {
    return booksIssued;
}

void Member::setBooksIssued(int booksIssued) {
    this->booksIssued = booksIssued;
}

bool Member::canIssueBook(Book* book) {
    // check if the member has reached their issuance limit for student
   
    
    if(this->getType() =="student"){
	       if (this->booksIssued >= 3  ) { 
	 	    std::cout << "You have already issued the maximum number of books allowed." << std::endl;
        return false;
    	}
	}
	
	if(this->getType() =="faculty"){
	       if (this->booksIssued >= 5  ) { 
	 	    std::cout << "You have already issued the maximum number of books allowed." << std::endl;
        return false;
    	}
	}
    
    // check if the book has already been issued to the member
    for (int i = 0; i < booksIssued; i++) {
        if (issuedBooks[i] == book) {
            std::cout << "You have already issued this book." << std::endl;
            return false;
        }
    }
    return true;
}

void Member::addIssuedBook(Book* book) {
    if (canIssueBook(book)) {
        issuedBooks[booksIssued++] = book;
        book->setIssuedTo(this);
    }
}

void Member::removeIssuedBook(Book* book) {
    for (int i = 0; i < booksIssued; i++) {
        if (issuedBooks[i] == book) {
            // Remove the book from the array of issued books
            for (int j = i; j < booksIssued - 1; j++) {
                issuedBooks[j] = issuedBooks[j+1];
            }
            issuedBooks[booksIssued - 1] = NULL;
            booksIssued--;
            break;
        }
    }
}

int Member::calculateFine(Book* book) {
    int fineAmount = 0;
    //for (int i = 0; i < booksIssued; i++) {
       
	    //Book* book 
	    
        int daysOverdue = book->daysOverdue();
        
        if (daysOverdue > 0) {
            fineAmount += daysOverdue * 10;
        }

    return fineAmount;
}

void Member::displayMemberDetails() {
    cout << "Member ID:           " << memberID << endl;
    cout << "Name:                " << name << endl;
    cout << "Phone number:        " << phone << endl;
    cout << "Total Books issued:  " << this->getBooksIssued() << endl;
    cout << "SNO\t" << "Book Name\t\t\t" << "Issue Date\t\t" << "Return Date\t\t" << "Fine" << endl;
    for (int i = 0; i < this->getBooksIssued(); i++) {
        if (issuedBooks[i] != NULL) {
            cout << i+1 << "\t";
            cout << issuedBooks[i]->getName() << "\t\t\t";
            issuedBooks[i]->print_issue_date();
            cout << "\t";
            issuedBooks[i]->print_return_date();
            cout << "\t";
           
            cout << endl;
        }
    }
}

void Member::displayallMemberDetails() {
    cout << "Member ID:        \t  " << memberID << endl;
    cout << "Name:              \t " << name << endl;
    cout << "Phone number:      \t " << phone << endl;
    cout << "Total Books issued: \t" << this->getBooksIssued() << endl;
   
   
            cout << endl;
        
    
}


void  Member:: displayMemberCardDetails() {
	
	cout << "Card ID: " << memberID << "\t\t";
    cout << "Name: " << name << "\t\t";
    cout << "Phone number: " << phone << endl;
   
    cout << "Total Books issued: " << this->getBooksIssued()   <<endl;
    cout<<"SNO\t" << "Book Name\t\t" << "Issue Date\t\t" <<"Return Date"<<endl;
    for (int i = 0; i < this->getBooksIssued()  ; i++) {
        if (issuedBooks[i] != NULL) {
            cout << i+1 << "\t" << issuedBooks[i]->getName();cout<<"\t";
			issuedBooks[i]->print_issue_date(); cout<<"\t";
			issuedBooks[i]->print_return_date();  
			
			cout<<endl;
        }
    }
}


// destructor
   Member:: ~Member() {
       
    }

    
    

