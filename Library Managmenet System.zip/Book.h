#pragma once

#include "Member.h"
#include<iostream>
#include <ctime> // for time() and tm

#include <iomanip> // for put_time




class Member; // forward declaration



using namespace std;

class Book{
private:
    string bookID;
    string name;
    string author;
    int edition;
    string purchaseDate;
    bool available;
    Member* issuedTo;
    time_t dateIssued; // date book was issued to member
    time_t datereturned; // date book was returned
   	int dayoverdue;
		
public:
	Book() {}
	
	    Book(string bookID, string name, string author, int edition, string purchaseDate, bool available = true) {
        this->bookID = bookID;
        this->name = name;
        this->author = author;
        this->edition = edition;
        this->purchaseDate = purchaseDate;
        this->available = available;
    }

virtual void inputDetails() {
   	std::cin.ignore();
    std::cout << "Enter book ID: ";
    std::getline(std::cin, bookID);
    
    std::cout << "Enter book name: ";
    std::getline(std::cin, name);
    
    std::cout << "Enter author name: ";
    std::getline(std::cin, author);
    
    std::cout << "Enter edition: ";
    std::cin >> edition;
    
    std::cin.ignore(); // Ignore the newline character left in the input buffer
    
    std::cout << "Enter purchase date (yyyy-mm-dd): ";
    std::getline(std::cin, purchaseDate);
    
    std::cout << "Is the book available (0 for no, 1 for yes)? ";
    std::cin >> available;
    
    std::cin.ignore(); // Ignore the newline character left in the input buffer
}


    string getBookID() {
        return bookID;
    }

    string getName() {
        return name;
    }

    string getAuthor() {
        return author;
    }

    int getEdition() {
        return edition;
    }

    string getPurchaseDate() {
        return purchaseDate;
    }



bool isAvailable() {
    return available;
}

void setAvailable(bool available) {
    this->available = available;
}

 void setIssuedTo(Member* member) {
    issuedTo = member;
}

Member* getIssuedTo() {
    return issuedTo;
}
// set issue date function
void set_issue_date(int year, int month, int day) {
        struct tm timeinfo = {0};
        timeinfo.tm_year = year - 1900;  // year since 1900
        timeinfo.tm_mon = month - 1;     // month since January
        timeinfo.tm_mday = day;          // day of the month
        dateIssued = mktime(&timeinfo);  // set issue date as Unix timestamp
   		
   		char dateBuffer[11];  // allocate buffer for formatted date string
   		strftime(dateBuffer, sizeof(dateBuffer), "%Y-%m-%d", localtime(&dateIssued));
    	
    }


time_t get_issue_date(void)
{
	
	return dateIssued;
}

void print_issue_date()
{
	char dateBuffer[11];  // allocate buffer for formatted date string
   		strftime(dateBuffer, sizeof(dateBuffer), "%Y-%m-%d", localtime(&dateIssued));
    	cout << dateBuffer ;  // print formatted date string
   		
}

// set return date function
void set_return_date(time_t issuance_date, std::string borrower_type) {
    // Define constants for the different due dates
    const time_t STUDENT_DUE_DATE = 14 * 86400;  // 14 days in seconds
    const time_t STAFF_DUE_DATE = 60 * 86400;   // 2 months in seconds

    // Calculate the due date based on the borrower type
    time_t due_date;
    if (borrower_type == "student") {
        due_date = issuance_date + STUDENT_DUE_DATE;
    } else {
        due_date = issuance_date + STAFF_DUE_DATE;
    }
	datereturned=due_date;

}

void set_return_date(time_t date)
{
	datereturned=date;
}


time_t get_return_date(void)
{
	return datereturned;
}

void print_return_date()
{
	char dateBuffer[11];  // allocate buffer for formatted date string
   		strftime(dateBuffer, sizeof(dateBuffer), "%Y-%m-%d", localtime(&datereturned));
    	cout << dateBuffer ;  // print formatted date string
   			
}

int daysOverdue() {
        if (!issuedTo) {
            cout << "This book has not been issued to anyone." << std::endl;
            return 0;
        }
    	int allowedDays=0;
	    if (this->issuedTo->getType() =="student")   	
        		 allowedDays = 14; // allowed number of days for book to be borrowed
        	else	
		         allowedDays = 60;
	   
	   
	    time_t now = time(NULL); // current time
        double seconds = difftime(this->datereturned ,this->dateIssued); // time difference in seconds
        int days = static_cast<int>(seconds / (24 * 60 * 60)); // convert to days
       	dayoverdue=days;
	    
        if (days <= allowedDays) {
            return 0; // book is not overdue
        } else {
			dayoverdue= days - allowedDays;     
			cout<<"Days overdue for this Book are"<<dayoverdue<<endl;
		    return days - allowedDays; // return number of days overdue
        }
    }

int geydaysoverdue()
{
	return dayoverdue;
}


void displayBookDetails() {
    std::cout << "Book ID: " << bookID << std::endl;
    std::cout << "Title: " << name << std::endl;
    std::cout << "Author: " << author << std::endl;
    std::cout << "Edition: " << edition << std::endl;
    std::cout << "Purchase : " << purchaseDate << std::endl;
    
	
	std::cout << "Available: " << (available ? "Yes" : "No") << std::endl;
    if (!available) {
        std::cout << "Issued To: " << issuedTo->getName() << std::endl;
    }
}

void displayallBookDetails() {
    
    std::cout << std::left << std::setw(10) << bookID 
              << std::setw(30) << name 
              << std::setw(20) << author 
              << std::setw(10) << edition 
              << std::setw(15) << purchaseDate 
              << std::setw(10) << (available ? "Yes" : "No") 
              << std::endl;
}



};

