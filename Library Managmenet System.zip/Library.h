//#pragma once

#include "Book.h"
#include "Member.h"

const int MAX_BOOKS=100;
const int MAX_MEMBERS=100;



class Library {
private:
    Book books[MAX_BOOKS]; // array of books in the library
    int numBooks; // number of books in the library
    Member members[MAX_MEMBERS]; // array of library members
    int numMembers; // number of library members

public:
    Library() {
	 numBooks=0;
	 numMembers=0; }
	 
    // Adds a new book to the library
    void addBook(Book *book) {
        
		
		if (numBooks < MAX_BOOKS) {
            books[numBooks++] = *book;
            std::cout << "Book added successfully!" << std::endl;
        }
        else {
            std::cout << "Library is full, cannot add more books." << std::endl;
        }
    }

    // Searches for a book in the library based on its ID
    Book* searchBook(std::string bookID) {
        for (int i = 0; i < numBooks; i++) {
            if (books[i].getBookID() == bookID) {
                return &books[i];
            }
        }
        return NULL;
    }

    // Issues a book to a registered member of the library
    void issueBook(std::string bookID, std::string memberID) {
        Book* book = searchBook(bookID);
        Member* member = searchMember(memberID);
        if (book && member) { 
            if (member->canIssueBook(book)) { 
                if (book->isAvailable()) { 
					book->setAvailable (false);
                    book->setIssuedTo(member);
                    // set issue date to current date
				    time_t now = time(0);
				    tm* ltm = localtime(&now);
				    int year = 1900 + ltm->tm_year;
				    int month = 1 + ltm->tm_mon;
				    int day = ltm->tm_mday;
				    book->set_issue_date(year, month, day) ;                 
                    //book->set_return_date(year, month, day) ;                                       
                    
                  	if(member->getType()=="student")
                  		book->set_return_date(book->get_issue_date (),"student");
				  	else
				  		book->set_return_date(book->get_issue_date (),"faculty");
				  
				 	 member->addIssuedBook(book);
				  
				   	
				   std::cout << "Book issued successfully to " << member->getName() <<"today on ";
				   	book->print_issue_date();
					cout<< " and expected date return is ";
					book->print_return_date();
					cout<<std::endl;
             
			    }
                else {
                    std::cout << "Sorry, the book is already issued to " << book->getIssuedTo()->getName() << std::endl;
                }
            }
            else {
                std::cout << "Sorry, the member has already reached the maximum number of books that can be issued." << std::endl;
            }
        }
        else {
            std::cout << "Invalid book ID or member ID." << std::endl;
        }
    }

    // Receives a book back from a registered member of the library
    
   void receiveBook(std::string bookID, std::string memberID) {
    Book* book = searchBook(bookID);
    Member* member = searchMember(memberID);
    	int day,month,year;
    if (book && member) {
        if (book->getIssuedTo() == member) {
                 
       	cout<<"Enter return date yy-mm-dd";
        cin>>year>>month>>day;
        struct tm timeinfo = {0};
        timeinfo.tm_year = year - 1900;  // year since 1900
        timeinfo.tm_mon = month - 1;     // month since January
        timeinfo.tm_mday = day;          // day of the month
        book->set_return_date(mktime(&timeinfo));  // set issue date as Unix timestamp
       	
	    cout << " issue date " ; book->print_issue_date () ; cout<< std::endl;
	    std::cout << "Return date " ; book->print_return_date () ;cout<< std::endl;
        std::cout << "Receiving book " << book->getName() << " from " << member->getName() << std::endl;

            
            // Step 1: Generate fine chalan if applicable
             int ans= book->daysOverdue() ;        
		
			
                generateFineChalan(member->getMemberID(), book->getBookID());
          

            // Step 2: Display confirmation message
            std::cout << "Book received successfully and status upadated" << std::endl;
            // Step 3: Update book and member status
            book->setAvailable(true);
            book->setIssuedTo(NULL);
          	member->removeIssuedBook(book);

        }
        else {
            std::cout << "The book was not issued to " << member->getName() << std::endl;
        }
    }
    else {
        std::cout << "Invalid book ID or member ID." << std::endl;
    }
}
 
// Generates a fine chalan for a registered member of the library
    void generateFineChalan(string memberID,string bookId) {
    Member* member = searchMember(memberID);
    Book* book=searchBook(bookId);
    if (member == NULL) {
        cout << "Error: member with ID " << memberID << " not found." << endl;
        return;
    }

    int fineAmount = member->calculateFine(book);
    if (fineAmount == 0) {
        cout << "No fines due for member " << member->getName() << "." << endl;
        return;
    }
	cout<<endl<<endl;
    cout << "Fine chalan for member " << member->getName() << ":" << endl;
    cout << "-------------------------------------" << endl;
    cout << "Member ID: " << member->getMemberID () << endl;
    cout << "Fines due: " << fineAmount << " Rs." << endl;
}

//add memeber to library
void addMember(Member member) {
    if (numMembers >= MAX_MEMBERS) {
        cout << "Error: maximum number of members reached." << endl;
        return;
    }

    // Check if member with same ID already exists
    if (searchMember(member.getMemberID ()) != NULL) {
        cout << "Error: member with ID " << member.getMemberID () << " already exists." << endl;
        return;
    }

    members[numMembers] = member;
    numMembers++;

    cout << "Member " << member.getName() << " added successfully." << endl;
}


// Search member
Member* searchMember(string memberID) {
    for (int i = 0; i < numMembers; i++) {
        if (members[i].getMemberID() == memberID) {
            return &members[i];
        }
    }
    return NULL;
}


void displayAllBooks() {
    if (numBooks == 0) {
        cout << "There are no books in the library." << endl;
        return;
    }

    cout << "List of all books in the library:" << endl;
    cout << "----------------------------------" << endl;
	std::cout << std::left << std::setw(10) << "Book ID" 
              << std::setw(30) << "Name" 
              << std::setw(20) << "Author" 
              << std::setw(10) << "Edition" 
              << std::setw(15) << "Purchase Date" 
              << std::setw(10) << "Available" 
              << std::endl;
	

    for (int i = 0; i < numBooks; i++) {
        books[i].displayallBookDetails();
    }
}

void displayAllMembers() {
    if (numMembers == 0) {
        cout << "There are no members in the library." << endl;
        return;
    }

    cout << "List of all members in the library:" << endl;
     
     
    for (int i = 0; i < numMembers; i++) {
        members[i].displayallMemberDetails();
    }
}



void displayReturnDates(std::string memberID) 
     {
    
        Member* member = searchMember(memberID);
    	if(!member)
    	{
			cout<< "No such member exists";
    		return;}
    	else
    		member->displayMemberDetails ();
    }


void displaycard(std::string memberID) 
     {
    	
        Member* member = searchMember(memberID);
    	
		
		if(!member)
    	{
			cout<< "No such member exists";
    		return;}
    	else
    		
			member->displayMemberCardDetails ();
    }
};
