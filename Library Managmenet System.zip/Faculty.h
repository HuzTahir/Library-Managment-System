#ifndef FACULTY_H
#define FACULTY_H

#include "Member.h"

class Faculty : public Member {
private: 
	int facultyBookLimit;
	int facultyDayslimit;
    int finePerDay;

public:
     
	 Faculty(){}
	 
	 
	 Faculty(string memberID, string name, string address, string phone, string type, int booksIssued)
        : Member(memberID,  name, address, phone, type, booksIssued) 
		{
		
		
		}
   
   void inputDetails() {
    Member::inputDetails();
    
    
}

    
   int getFacultyBookLimit() const {
       
	    return facultyBookLimit;
    }
    
    void setFacultyBookLimit(void) {
        facultyBookLimit = 5;
    }
    
    int getFacultyDaysLimit() const {
       
	    return facultyDayslimit;
    }
    
    void setFacultyDaysLimit(int limit) {
        facultyDayslimit = 60;
    } 
    
};

#endif // FACULTY_H

