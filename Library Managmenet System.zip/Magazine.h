//#pragma once
//using namespace std;

class Magazine : public Book {
private:
    int issueNumber;
    string publisher;
public:
    Magazine(){
	}
	Magazine(string id, string name, string author, int edition, string purchaseDate, bool available,  string publisher) 
        : Book(id, name, author, edition, purchaseDate, available) {
        this->issueNumber = issueNumber;
        this->publisher = publisher;
    }
    
  void inputDetails() override {
        Book::inputDetails();
        cout << "Enter publisher: ";
        cin >> publisher;
    }
  
   int getIssueNumber() const {
        return issueNumber;
    }
    
    string getPublisher() const {
        return publisher;
    }
};

