
//#pragma once

//using namespace std;
class Journal : public Book {
private:
    int volumeNumber;
    string publisher;
public:
    
	Journal() {}
	
	Journal(string id, string name, string author, int edition, string purchaseDate, bool available, string publisher) 
        : Book(id, name, author, edition, purchaseDate, available) {
        this->volumeNumber = volumeNumber;
        this->publisher = publisher;
    }
    
    void inputDetails() override {
        Book::inputDetails();
        cout << "Enter edition:Weekly or Monthly ";
        cin >> publisher;
        
    }
    
    int getVolumeNumber() const {
        return volumeNumber;
    }
    
    string getPublisher() const {
        return publisher;
    }
};

