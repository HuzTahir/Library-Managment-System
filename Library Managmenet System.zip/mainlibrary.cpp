//#pragma once

#include <iostream>
#include <string>
#include <conio.h>

#include "Librarian.h"
#include "Library.h"
#include "Member.h" 
#include "Magazine.h"
#include "Journal.h"
#include "Book.h"
#include "StudyBook.h"
#include "Student.h"
#include "Faculty.h" 
int display_menu();

using namespace std;

int main() {
    // Create a new librarian
    Librarian librarian("huzifa", "123");

    // Login as librarian
    bool logged_in = false;
    while (!logged_in) {
        std::string username, password;
        std::cout << "Enter your username: ";
        std::cin >> username;
        std::cout << "Enter your password: ";
        std::cin >> password;
        if (librarian.login(username, password)) {
            std::cout << "Login successful!" << std::endl;
            logged_in = true;
        } else {
            std::cout << "Incorrect username or password. Please try again." << std::endl;
        }
    }

			Library library;
			StudyBook studybook_obj("B001", "Data Structures and Algorithms", "John Smith", 2, "2022-01-01", true, "Computer Science");
		

			// create 5 StudyBook objects
			StudyBook studybook_obj1("S001", "Data Structures and Algorithms", "John Smith", 2, "2022-01-01", true, "Computer Science");
			StudyBook studybook_obj2("S002", "Object-Oriented Programming", "Jane Doe", 1, "2022-02-01", true, "Computer Science");
			StudyBook studybook_obj3("S003", "Database Systems", "Alice Johnson", 3, "2022-03-01", true, "Computer Science");
			StudyBook studybook_obj4("S004", "Operating Systems", "Bob Lee", 4, "2022-04-01", true, "Computer Science");
			StudyBook studybook_obj5("S005", "Computer Networks", "Emily Kim", 2, "2022-05-01", true, "Computer Science");

			// create 3 Journal objects
			Journal journal_obj1("J001", "IEEE Transactions on Robotics", "IEEE", 1, "2022", true, "Monthly");
			Journal journal_obj2("J002", "Nature Communications", "Nature Research",1,  "2022",true, "Weekly");
			Journal journal_obj3("J003", "American Science", "American Association", 1, "2022", true, "Weekly");

			// create 2 Magazine objects
			Magazine magazine_obj1("M001", "National Geographic", "National Geographic", 1,"2022", true, "Monthly");
			Magazine magazine_obj2("M002", "TIME", "TIME USA, LLC", 1, "2022",  true, "Weekly");

			// create an array of Book pointers to store all the objects
			Book* book[10];
			Magazine magazine ;
			Journal journal;
			StudyBook studybook;
			Faculty temp1;
			Student temp2;
			Member temp3;
			
			// assign each object to a Book pointer in the array
			book[0] = &studybook_obj1;
			book[1] = &studybook_obj2;
			book[2] = &studybook_obj3;
			book[3] = &studybook_obj4;
			book[4] = &studybook_obj5;
			book[5] = &journal_obj1;
			book[6] = &journal_obj2;
			book[7] = &journal_obj3;
			book[8] = &magazine_obj1;
			book[9] = &magazine_obj2;
    		
    		// Create 3 students and 2 faculty members
   
			Student s1("S001", "John Doe", "123 Main St", "555-1234", "student", 0,3,14);
			Faculty f1("F001", "Jane Smith", "456 Oak Ave", "555-5678", "faculty", 0);
			Student s2("S002", "Bob Johnson", "789 Elm St", "555-2468", "student", 0,3,14);
			Faculty f2("F002", "Sara Lee", "321 Pine Ave", "555-9876", "faculty", 0);
			Student s3("S003", "Mike Scott", "654 Birch Rd", "555-1357", "student", 0,3,14);
			Student s4("S004", "Tom cruise", "123 Main St", "555-1234", "student", 0,3,14);
    		
			Member& member1=s1;
			Member& member2=s2;
			Member& member3=s3;
			Member& member4=s4;
			Member& member5=f1;
			Member& member6=f2;
			
    	
			int choice;
			string bookID;	string memberID;
			string str; int booktype;

	while(choice !=0 )
	{
		choice=display_menu();
		switch(choice)
		{
	
		case 0:
			return 1;
			break;
		
	   	case 1:
   			// Add 10 books to the library database
   			system("cls");
			
			for(int i=0; i<10;i++)
			library.addBook(book[i]) ;
			cout<<"********* 10 books added successfully*******";
			system("pause");
		break;
		
		case 2:	
			cout<<"Enter Book category No(1-3) i.e Mazgine, Journal, Study book";
			cin>>booktype;
			std::cin.ignore();
				if(booktype==1)
				{
					
					magazine.inputDetails();
					library.addBook(&magazine);
				}
			
			
			if(booktype==2)
				{
					
					journal.inputDetails();
					library.addBook(&journal);
				}
			
			if(booktype==3)
				{
					
					studybook.inputDetails();
					library.addBook(&studybook);
				}
			system("pause");
		break;
		
    	case 3:
			system("cls");
			library.addMember(member1) ;
			library.addMember(member2) ;
			library.addMember(member3) ;
			library.addMember(member4) ;
			library.addMember(member5) ;
			library.addMember(member6) ;
			cout<<"********* Members added successfully*******";
			system("pause");
		break;
	
		case 4:
			system("cls");
			temp3.inputDetails() ;
			library.addMember(temp3) ;
			system("pause");
			
		break;	
		
				
		case 5:
			system("cls");
			library.displayAllBooks() ;
			system("pause");
		break;
		
		case 6:
			system("cls");
			library.displayAllMembers() ;
			system("pause");
		break;

    
    	// Student 1 should be able to issue 2 studyBooks and a magazine
  		case 7:
  		 
	         library.issueBook("S001","S001");
	         library.issueBook("S004","S001");
	         library.issueBook("M001","S001");
       	
    	// Student 2 should be able to issue 1 journal
	        	
       		 library.issueBook("J001","S001");
    	
    	// Student 3 can issue a magazine and a study book
 		   		
        	library.issueBook("J002","S003");
        	library.issueBook("M002","S003");
         
		
  		// Staff member should be able to issue 2 journals and a studybook
   
       		 library.issueBook("J002","F001");
       		 library.issueBook("J003","F001");
        	 library.issueBook("S005","F001");
  
			system("pause");
	break;
    
    
	case 8:
		
		cout<<"Enter Book Id to issue\n";
		cin>>bookID;
	

		cout<<"Enter memeber Id to whom book is isssued\n";
		cin>>memberID;
		library.issueBook(bookID,memberID);
		system("pause");
	break;	
	
	
	case 9:

    	// Display book return date for all books issued by Student 1
	
		cout<<"Enter memeber Id to check return dates\n";
		cin>>str;
	  
	   	library.displayReturnDates(str) ; 
	    
	    std::cout << std::endl;
		system("pause");
	break;
	

	case 10:
	
		cout<<"Enter Book Id to return dates\n";
		cin>>bookID;
		
	
		cout<<"Enter memeber Id from whom book is returned\n";
		cin>>memberID;
		
		library.receiveBook(bookID,  memberID);	
		system("pause");
	break;


	case 11:
		
		cout<<"Enter memeber Id to display Card\n";
		cin>>memberID;
		
		library.displaycard(memberID);	
		system("pause");
	break;	
		

	}//switch

}//loop

}



int display_menu() {
    system("cls");
	cout << "Library System Menu" << endl;
    cout << "1. Add books ib Bulk into  Library" << endl;
   	 cout <<"2. Add individual Book" << endl;
   	cout << "3. Create members i.e 3 students and 2 Faculty members" << endl;
    cout << "4. Create individaul members " << endl;
	cout << "5. Display status of Books in Library" << endl;
    cout << "6. Display all members & number of books they have issued" << endl;
	cout << "7. Issue books to students and faculty in bulk" << endl;
    cout << "8. Issue books to individual memebr" << endl;
	cout << "9. Display return date of all the books issued by Student" << endl;
    cout << "10. Return the books & Calculate fine fine" << endl;
    cout << "11. Update the status of returned book & user" << endl;
    cout << "0. Exit" << endl;
    int choice;
    cout << "Enter your choice: ";
    cin >> choice;
    return choice;
}
