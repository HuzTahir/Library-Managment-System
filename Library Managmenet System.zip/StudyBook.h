

class StudyBook : public Book {
private:
    string subject;

public:
   
StudyBook() {}
	
StudyBook(string bookID, string name, string author, int edition, string purchaseDate, bool available, string subject)
    : Book(bookID, name, author, edition, purchaseDate, available), subject(subject) {}	

void inputDetails() override {
        Book::inputDetails();
        cout << "Enter subject: ";
        cin >> subject;
}
    string getSubject() {
        return subject;
    }

    void setSubject(string subject) {
        this->subject = subject;
    }

  
};

