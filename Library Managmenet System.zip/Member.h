#pragma once
#ifndef MEMBER_H
#define MEMBER_H

#include <string>


// Forward declaration of the Book class
class Book;
using namespace std;

class Member {
private:
    string memberID;
    string name;
    string address;
    string phone;
    Book* issuedBooks[15]; // Array to store issued books
    
    string type;
    int booksIssued;
    int totalfine;  

public:
	Member(void); 
	Member(string memberID, string name, string address, string phone, string type, int booksIssued);
    void inputDetails();
	string getMemberID();
    string getName();
    string getAddress();
    string getPhone();
    string getType();
    int getBooksIssued();
    void setBooksIssued(int booksIssued);
    bool canIssueBook(Book* book);
    void addIssuedBook(Book* book);
    void removeIssuedBook(Book* book);
    int calculateFine(Book* book);
    void displayMemberDetails();
    void displayallMemberDetails();
    void displayMemberCardDetails ();
   
  
    ~Member();
};

#endif // MEMBER_H



