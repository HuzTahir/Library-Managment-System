//#pragma once

using namespace std;

class Librarian {
private:
    std::string username;
    std::string password;

public:
    // Constructor
    Librarian(const std::string& username, const std::string& password)
        : username(username), password(password) {}

    // Getters
    std::string getUsername() const { return username; }
    std::string getPassword() const { return password; }

    // Setters
    void setUsername(const std::string& username) { this->username = username; }
    void setPassword(const std::string& password) { this->password = password; }

    // Login method
    bool login(const std::string& username, const std::string& password) {
        return (this->username == username && this->password == password);
    }


};

