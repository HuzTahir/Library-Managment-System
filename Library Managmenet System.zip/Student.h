#ifndef STUDENT_H
#define STUDENT_H

#include "Member.h"

class Student : public Member {
private:

	int studentBookLimit;
	int studentDayslimit;
    int finePerDay;

public:
  
  Student() {}
  
   Student(string memberID, string name, string address, string phone, string type, int booksIssued,int book,int days)
        : Member(memberID,  name, address, phone, type, booksIssued) 
		
		{
			
		studentBookLimit=book;
		studentDayslimit=days;
		}
   
  void inputDetails() {
    Member::inputDetails();
    
}

    
    string getType() {
        return "student";
    }
    
 	
	int getStudentBookLimit() const {
       
	    return studentBookLimit;
    }
    
    void setStudentBookLimit(void) {
        studentBookLimit = 3;
    }
    
    int getStudenDaysLimit() const {
       
	  //  return studentDayslimit;
	  return 3;
    }
    
    void setStudentDaysLimit(void) {
        studentDayslimit = 14;
    }
    
};

#endif // STUDENT_H




